﻿/* Add Human or Dept Info End */

/* Mask Control Block Script Start */

function eflow_net_CoverMe() {
    $("div.window-mask").each(function() {
        var DownDivID = this.DownDivID;
        var oDownDiv = document.getElementById(DownDivID);
        if (oDownDiv) {
            this.style.height = oDownDiv.offsetHeight;
            this.style.width = oDownDiv.offsetWidth;
            pos = eflow_net_getAbsolutePos(oDownDiv);
            this.style.top = pos.yPos;
            this.style.left = pos.xPos;
        }
    });
}

function eflow_net_getAbsolutePos(el) {
    if (el) {
        var obj = new Object();

        obj.xPos = el.offsetLeft;
        obj.yPos = el.offsetTop;
        tempEl = el.offsetParent;
        while (tempEl != null) {
            obj.xPos += tempEl.offsetLeft;
            obj.yPos += tempEl.offsetTop;
            tempEl = tempEl.offsetParent;
        }

        return obj;
    }
}
/* Mask Control Block Script End */

function ShowProgress() {
    $('body').toggleLoading();

}

function CheckSelectUser(NextUser, NextStateID, CommandID, StopID, IsAutoID) {

    if ($("#" + IsAutoID + "").val() == 'false') {
        var ids = [];
        var actionInfo = $("#" + CommandID + "").val();
        var actionInfoList = actionInfo.split("^");
        var mCommandName = "";
        if (actionInfoList.length > 0) {
            var actionValue = actionInfoList[1].split(":");
            mCommandName = actionValue[5];
        }
        var IsEndState = $("#" + StopID + "").val();
        if (mCommandName == "Approve" && IsEndState == "false") {

            if ($('#HidHuiqian').val() == "1") {
                $('#FlowUserInfo').datagrid('selectAll');
            }
            var rows = $('#FlowUserInfo').datagrid('getSelections');
            if (rows == '') { $.messager.alert('warning', '請選擇人員!', 'warning'); return false; }
            else {
                for (var i = 0; i < rows.length; i++) {
                    ids.push("1:" + rows[i].UserPKID + ":" + rows[i].UserName + ":" + rows[i].UserSID);
                    $("#" + NextStateID + "").val(rows[i].NextStateID);
                }
                $("#" + NextUser + "").val(ids.join('^'));
                $('#SelectUserDialog').dialog('close');
                $('#DlgAdvice').css('display', 'none');
                ShowProgress();
                return true;
            }
        }
        else if (mCommandName == "Rejection") {
            var selected = $('#FlowUserInfo').datagrid('getSelected');
            if (selected) {
                $("#" + NextStateID + "").val(selected.NextStateID);
                $("#" + NextUser + "").val("1:" + selected.UserPKID + ":" + selected.UserName);
                $('#SelectUserDialog').dialog('close');
                $('#DlgAdvice').css('display', 'none');
                ShowProgress();
                return true;
            }
            else {

                $.messager.alert('warning', '請選擇駁回人員!', 'warning'); return false;
            }
        }
        else {
            $('#SelectUserDialog').dialog('close');
            $('#DlgAdvice').css('display', 'none');
            ShowProgress();
            return true;
        }
    }
    else {
        $('#SelectUserDialog').dialog('close');
        $('#DlgAdvice').css('display', 'none');
        ShowProgress();
        return true;
    }
}
$(document).ready(function() {
    eflow_net_CoverMe();
    $("#SelectUserDialog").dialog({
        modal: true,
        title: "請選擇人員信息",
        width: 720,
        height: 400
    });
});
var ExitUser = '';
function AddUser(value) {
    //var InputName = encodeURI(inputValue);
    if (value != "") {
        $.ajax({
            url: 'http://localhost/eFlowDoc/EFlowNet/eFLowHandler.ashx?type=add',
            type: "POST",
            data: 'UserName=' + value,
            success: function(response) {
                if (response == "")
                { alert("沒有找到您輸入條件對應的人員信息！"); }
                else {
                    var UserInfo = response.split('^');
                    var StateName = "";
                    var selected = $('#FlowUserInfo').datagrid('getSelected');
                    if (selected) {
                        var rowIndex = $('#FlowUserInfo').datagrid('getRows').length;
                        for (var i = 0; i < UserInfo.length; i++) {
                            NextStateID: selected.NextStateID
                            var mUser = UserInfo[i].split(",");
                            if (ExitUser.indexOf(mUser[2]) != -1) {
                            }
                            else {
                                $('#FlowUserInfo').datagrid('insertRow', { index: rowIndex + i,
                                    row: {
                                        StateName: selected.StateName,
                                        UserPKID: mUser[0],
                                        UserName: mUser[1],
                                        UserSID: mUser[2],
                                        NextStateID: selected.NextStateID
                                    }
                                });
                                ExitUser = ExitUser + mUser[2] + ',';
                            }
                        }
                        $('#Seabox').searchbox('setValue', "");
                        $('#FlowUserInfo').datagrid('acceptChanges');
                    }

                }
            }
        });
    }
    else
    { alert("請輸入要添加的人員姓名！"); }
}

function ActionListValidate() {
    if ($("#FlagUnique").length==0) {
        return $('form').form("validate");
    }
    else {
        return SelfActionListValidate();
    }
}

